
document.addEventListener('DOMContentLoaded', function () {

    // Mobile navigation
    const navToggle = document.querySelector('.nav-toggle');
    const mainNav = document.querySelector('#main-nav');

    if (navToggle && mainNav) {
        navToggle.addEventListener('click', function () {
            const open = mainNav.classList.toggle('open');
            navToggle.setAttribute('aria-expanded', String(open));
        });
    }

    // Contact form demonstration
    const contactForm = document.querySelector('#contact-form');
    const formMessage = document.querySelector('#form-message');

    if (contactForm && formMessage) {
        contactForm.addEventListener('submit', function (event) {
            event.preventDefault();
            formMessage.textContent =
                'Thank you. Your message has been recorded for this demonstration.';
            contactForm.reset();
        });
    }

    // Menu search
    const menuSearch = document.querySelector('#menuSearch');
    const menuItems = document.querySelectorAll('.menu-item');
    const searchMessage = document.querySelector('#searchMessage');

    if (menuSearch && menuItems.length > 0) {
        menuSearch.addEventListener('input', function () {
            const searchTerm = menuSearch.value.trim().toLowerCase();
            let visibleCount = 0;

            menuItems.forEach(function (item) {
                const matches = item.textContent.toLowerCase().includes(searchTerm);
                item.style.display = matches ? '' : 'none';

                if (matches) visibleCount++;
            });

            if (searchMessage) {
                searchMessage.textContent = visibleCount === 0
                    ? 'No menu items found. Try another search.'
                    : visibleCount + ' menu item(s) found.';
            }
        });
    }

    // Gallery lightbox
    const galleryImages = document.querySelectorAll('.lightbox-image');
    const lightbox = document.querySelector('#lightbox');
    const lightboxImg = document.querySelector('#lightboxImg');
    const lightboxCaption = document.querySelector('#lightboxCaption');
    const closeButton = document.querySelector('#lightboxClose');

    if (lightbox && lightboxImg && closeButton) {

        galleryImages.forEach(function (image) {
            image.addEventListener('click', function () {
                lightboxImg.src = image.src;
                lightboxImg.alt = image.alt;

                const caption = image.closest('figure')
                    ?.querySelector('figcaption');

                lightboxCaption.textContent =
                    caption ? caption.textContent : image.alt;

                lightbox.classList.add('active');
                lightbox.setAttribute('aria-hidden', 'false');
            });
        });

        function closeLightbox() {
            lightbox.classList.remove('active');
            lightbox.setAttribute('aria-hidden', 'true');
            lightboxImg.src = '';
        }

        closeButton.addEventListener('click', closeLightbox);

        lightbox.addEventListener('click', function (event) {
            if (event.target === lightbox) {
                closeLightbox();
            }
        });

        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape' && lightbox.classList.contains('active')) {
                closeLightbox();
            }
        });
    }

});
