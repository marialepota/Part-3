# Skyf Tobacco and Shisanyama – WEDE5020W Part 2

## Project overview
This Part 2 project develops the website for **Skyf Tobacco and Shisanyama**. The website presents the business as a South African food and entertainment destination offering freshly prepared food, drinks, a braai area, entertainment and a paid Hubbly/smoking hub facility.

The project focuses on CSS styling, desktop layout, responsive design, responsive images and basic JavaScript interaction.

## Website pages
- `index.html` – Home
- `about.html` – About Us
- `menu.html` – Menu
- `facilities.html` – Facilities
- `gallery.html` – Gallery
- `contact.html` – Contact Us

## Part 2 requirements implemented
### 2.1 External stylesheet
- All HTML pages link to the same external stylesheet: `css/style.css`.
- CSS class names are used consistently across pages.

### 2.2 Base styling
- Added a CSS reset with the universal selector.
- Added a consistent colour palette using charcoal/black, warm orange, deep red, cream and white.
- Set a default font family, base font size, line height, margins and padding.

### 2.3 Typography
- Added a clear heading hierarchy for `h1`, `h2` and `h3`.
- Used `clamp()` for responsive heading sizes.
- Applied font weight, line height, letter spacing and text-transform where appropriate.
- Used relative units such as `rem`, `%`, `vw` and `clamp()`.

### 2.4 Layout
- Used Flexbox for the navigation and buttons.
- Used CSS Grid for cards, menu items, gallery content and the contact layout.
- Desktop layouts use multiple columns, while smaller screens change to fewer columns or a single column.

### 2.5 Visual styling
- Added backgrounds, borders, rounded corners and box shadows.
- Added `:hover`, `:focus` and `:focus-visible` states for interactive elements.
- Added visible keyboard-focus styling for accessibility.

## Responsive design
### 3.1 Breakpoints
The stylesheet contains responsive breakpoints for:
- Desktop: above 900px
- Tablet: 601px–900px
- Mobile: 600px and below

The navigation changes to a mobile menu, multi-column grids collapse and content spacing is reduced on smaller screens.

### 3.2 Relative units
The website uses relative units including `%`, `rem`, `vw` and `clamp()` instead of relying only on fixed pixel sizes.

### 3.3 Responsive images
The project uses responsive images with `srcset` and `sizes` on the main photographic content. Several supplied photographs were resized into WebP versions so that the browser can select a suitable image size for the device.

The homepage hero also uses the `<picture>` element with a mobile source.

### 3.4 Testing
The website was tested at desktop, tablet and mobile responsive views. The screenshots below are included as evidence of the responsive testing and are stored in the `screenshots/` folder.

| View | Screenshot | What it demonstrates |
|---|---|---|
| Desktop | `screenshots/desktop-home.png` | Full desktop navigation, hero layout and multi-column content |
| Tablet | `screenshots/tablet-home.jpeg` | Responsive tablet layout with adjusted navigation and content columns |
| Mobile | `screenshots/mobile-home.jpeg` | Mobile menu, stacked content cards and responsive images |

#### Desktop testing
![Skyf desktop responsive test](screenshots/desktop-home.png)

#### Tablet testing
![Skyf tablet responsive test](screenshots/tablet-home.jpeg)

#### Mobile testing
![Skyf mobile responsive test](screenshots/mobile-home.jpeg)

## Business information used
The following information was supplied for this student website project:

- **Business name:** Skyf Tobacco and Shisanyama
- **Address:** Shabangu Ave, Mamelodi - QD4, Pretoria, 0122
- **Telephone:** 076 363 9006
- **Instagram:** @skyftobacco
- **Monday–Thursday:** 9:00 am–9:00 pm
- **Friday:** 9:00 am–2:00 am
- **Saturday:** 9:00 am–2:00 am
- **Sunday:** 9:00 am–12:00 am
- **Large meat platter:** approximately R650, depending on size/meat assortment
- **Skyf Meal for Two:** approximately R180
- **Sides:** chakalaka, pap and chips
- **Drinks:** alcoholic and non-alcoholic beverages at the main bar

Prices are shown as approximate because they may change. Email and WhatsApp details were not supplied and are not presented as confirmed contact methods.

## Images
The website uses the photographs supplied for this project. The files were resized for responsive use and the supplied Hubbly/social-area photograph was corrected for orientation before being used on the website.

The project also includes a link to the supplied Instagram profile **@skyftobacco**. Individual Instagram photos were not copied into the project because the supplied share link did not provide downloadable image files in this environment. If additional social-media photographs are added later, confirm that the business has permission to use them.

## Changelog
### Part 2 – final update
- Added the verified Instagram profile reference **@skyftobacco** to the Contact page, About page and site footers.
- Rewrote the About page in a professional customer-facing style and removed unsupported founder details.
- Updated the business name throughout the project to **Skyf Tobacco and Shisanyama**.
- Updated the logo text, page titles, descriptions, headings, navigation and footer text.
- Updated menu wording to match the correct business name.
- Replaced placeholder website imagery with the supplied photographs.
- Added responsive image versions in WebP format.
- Added `srcset` and `sizes` attributes to photographic content.
- Added a `<picture>` element for the homepage hero image.
- Improved desktop, tablet and mobile layouts using CSS Grid and Flexbox.
- Added responsive navigation for small screens.
- Added hover, focus and active states to interactive elements.
- Added keyboard-focus styling and accessible image alternative text.
- Added a responsive opening-hours table on the Contact page.
- Added a basic JavaScript contact-form demonstration.
- Prepared the layout for desktop, tablet and mobile testing at the documented viewport sizes.
- Added desktop, tablet and mobile screenshot evidence to the `screenshots/` folder and linked the evidence in this README.

### Part 1 feedback / corrections
The business name was corrected after confirming that the correct name is **Skyf Tobacco and Shisanyama**. The Part 2 website now uses this name consistently.

## GitHub submission checklist
Before submitting the repository:
1. Open every HTML page and check the navigation links.
2. Test the mobile menu.
3. Check the desktop, tablet and mobile layouts.
4. Confirm that the business name is spelled **Skyf Tobacco and Shisanyama** everywhere.
5. Commit the final changes with a descriptive Git message.
6. Push the final project to the remote GitHub repository.
7. Submit the GitHub repository link on the LMS.

## Technical references
- MDN Web Docs – CSS Grid Layout: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_grid_layout
- MDN Web Docs – CSS Media Queries: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_media_queries
- MDN Web Docs – Responsive Images: https://developer.mozilla.org/en-US/docs/Web/HTML/Guides/Responsive_images
- MDN Web Docs – Using the `<picture>` element: https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/picture



## CHANGELOG – Part 3

### Website Improvements

- Improved SEO across all six website pages.
- Added unique page titles and meta descriptions.
- Added relevant keywords and author information.
- Improved search engine visibility for Skyf Tobacco and Shisanyama in Mamelodi, Pretoria.
- Added robots.txt to guide search engine crawlers.
- Created sitemap.xml listing all six website pages.
- Added a JavaScript search feature to the Menu page, allowing customers to search for food items by name.
- Added image lightbox functionality to the Gallery page (pending successful testing).

### Testing

- Tested the website using Visual Studio Code Live Server.
- Checked that the Menu search feature works.
- Gallery lightbox still requires troubleshooting.
## Part 3 – Website Improvements and Changelog

### 1. JavaScript Enhancements
- Added a searchable menu feature that allows customers to search for menu items by name.
- Added a gallery lightbox feature to allow customers to view images in a larger format. (Feature added but still requires testing and troubleshooting.)

### 2. Search Engine Optimisation (SEO)
- Improved page titles and meta descriptions across all six website pages.
- Added relevant keywords to improve search visibility.
- Improved image descriptions using meaningful alt text.

### 3. Technical SEO
- Created a `robots.txt` file to guide search engine crawlers.
- Created a `sitemap.xml` file listing the website pages.

### 4. Testing
- Tested the website using Visual Studio Code and Live Server.
- Checked website navigation and menu search functionality.
- Gallery lightbox functionality still requires further testing.

### 5. Tools Used
- Visual Studio Code
- HTML5
- CSS3
- JavaScript
- Live Server extension